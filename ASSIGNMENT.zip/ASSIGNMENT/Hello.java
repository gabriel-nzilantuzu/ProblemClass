public class Hello {

    public static void main(String[] args) {
        int height = 20;
        String name = "Erica";

        Info obj = new Info(name, height);
        System.out.println(obj);
    }
}


