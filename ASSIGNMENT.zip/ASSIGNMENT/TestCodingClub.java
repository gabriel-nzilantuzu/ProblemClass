public class TestCodingClub {
    public static void main(String[] args) {
        CodingClubManager manager = new CodingClubManager();

        // Add members
        Member member1 = new Member("Alice", 101);
        Member member2 = new Member("Bob", 102);
        Member member3 = new Member("Erica", 103);
        manager.addMember(member1);
        manager.addMember(member2);
        manager.addMember(member3);

        // Display members
        manager.displayMembers();

        // Record payments
        manager.recordPayment(101, new Payment("January", 50.0));
        manager.recordPayment(101, new Payment("February", 50.0));
        manager.recordPayment(102, new Payment("January", 50.0));
        manager.recordPayment(103, new Payment("January", 100.0));
        manager.recordPayment(103, new Payment("March", 100.0));

        // Get payment history
        manager.getPaymentHistory(101);
        manager.getPaymentHistory(103);

        // Delete a member
        manager.getPaymentHistory(102);
        manager.deleteMember(102);
        manager.getPaymentHistory(102);
        manager.displayMembers();
    }
}
